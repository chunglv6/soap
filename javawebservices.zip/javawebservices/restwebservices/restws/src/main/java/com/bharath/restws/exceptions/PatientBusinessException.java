package com.bharath.restws.exceptions;

public class PatientBusinessException extends RuntimeException {

	private static final long serialVersionUID = 1L;

}
