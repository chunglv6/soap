package com.bharath.restws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestattachmentsclientApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestattachmentsclientApplication.class, args);
	}
}
