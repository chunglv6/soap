package com.example.wsdlFirst;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsdlFirstApplicationTests {

	@Test
	void contextLoads() {
	}

}
