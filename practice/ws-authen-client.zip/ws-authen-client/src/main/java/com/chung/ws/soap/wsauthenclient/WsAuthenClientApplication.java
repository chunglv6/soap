package com.chung.ws.soap.wsauthenclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WsAuthenClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(WsAuthenClientApplication.class, args);
	}

}
