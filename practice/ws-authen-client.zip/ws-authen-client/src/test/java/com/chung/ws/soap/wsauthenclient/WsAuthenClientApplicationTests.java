package com.chung.ws.soap.wsauthenclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WsAuthenClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
