package com.bharath.jersey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JerseydemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JerseydemoApplication.class, args);
	}

}
