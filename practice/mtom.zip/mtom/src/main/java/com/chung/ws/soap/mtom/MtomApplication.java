package com.chung.ws.soap.mtom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MtomApplication {

	public static void main(String[] args) {
		SpringApplication.run(MtomApplication.class, args);
	}

}
