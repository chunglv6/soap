package com.chung.ws.soap.mtom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MtomApplicationTests {

	@Test
	void contextLoads() {
	}

}
