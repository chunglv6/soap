package com.example.soapws.hellowebservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HellowebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
