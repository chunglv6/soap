package com.example.soapws.hellowebservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HellowebserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(HellowebserviceApplication.class, args);
	}

}
