package com.example.restws;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestwsApplicationTests {

	@Test
	void contextLoads() {
	}

}
